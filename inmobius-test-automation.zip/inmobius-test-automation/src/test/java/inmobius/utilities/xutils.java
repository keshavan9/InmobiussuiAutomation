package inmobius.utilities;



import static org.testng.Assert.assertEquals;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.bouncycastle.jcajce.provider.keystore.BC;
import org.json.JSONException;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import inmobus.testcases.base_class;
import io.restassured.RestAssured;
import io.restassured.response.Response;

public class xutils {
	public Response response;
	public Map<String, Object> map;
	public Map<String, Object> headerMap;
	public static FileInputStream fi;
	public static FileOutputStream fo;
	public static XSSFWorkbook wb;
	public static XSSFSheet ws;
	public static XSSFRow row;
	public static XSSFCell cell;
	
	
	
	
	public String generateOTP(String isd_code, String phone, String tenant_id, String product_id) {
		headerMap = new HashMap<String, Object>();
		headerMap.put("Content-Type", "application/json");
		map = new HashMap<String, Object>();
		map.put("isd_code" , isd_code);
		map.put("phone", phone);
		map.put("tenant_id", tenant_id);
		map.put("product_id", product_id);
		System.out.println(map);

         response = RestAssured.given().body(map)
                .baseUri("https://otp.infinitylearn.com")
                .headers(headerMap)
                .post("/api/getGatewayOtp"); 
         assertEquals(200,response.getStatusCode());
         String OTP = response.asString();
         System.out.println("Response received is :: " +OTP);
		return OTP;
            
            
        }
	public static String event_start_time() {
		   LocalDateTime now = LocalDateTime.now();
	        // Add one hour to the current time and subtract it from 24 hours
	        LocalDateTime minusOneHour = now.plusHours(1).minusHours(24);
	       // Format the date and time to a desired format
	        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm");
	       String Time=minusOneHour.format(formatter);
			return Time;
	}
	
	public static String event_end_time() {
		   LocalDateTime now = LocalDateTime.now();
	        // Add one hour to the current time and subtract it from 24 hours
	        LocalDateTime minusOneHour = now.plusHours(2).minusHours(24);
	        // Format the date and time to a desired format
	        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm");
	       String time= minusOneHour.format(formatter);
	       return time;
	}
	
	
	public static int getRowCount(String xlfile,String xlsheet) throws IOException
	{
		fi = new FileInputStream(xlfile);
		wb = new XSSFWorkbook(fi);
		ws = wb.getSheet(xlsheet);
		int rowCount = ws.getLastRowNum();
		wb.close();
		fi.close();
		return rowCount;
	}
	
	public static int getCellCount(String xlfile,String xlsheet,int rownum) throws IOException
	{
		fi = new FileInputStream(xlfile);
		wb = new XSSFWorkbook(fi);
		ws = wb.getSheet(xlsheet);
		row = ws.getRow(rownum);
		int cellCount = row.getLastCellNum();
		wb.close();
		fi.close();
		return cellCount;
	}
	
	public static String getCellData(String xlfile,String xlsheet,int rownum,int colnum) throws IOException
	{
		fi = new FileInputStream(xlfile);
		wb = new XSSFWorkbook(fi);
		ws = wb.getSheet(xlsheet);
		row = ws.getRow(rownum);
		cell = row.getCell(colnum);
		String data;
		try
		{
			DataFormatter formatter = new DataFormatter();
			String cellData = formatter.formatCellValue(cell);
			return cellData;
		}
		catch(Exception e)
		{
			data = "";
		}
		wb.close();
		fi.close();
		return data;
	}
	
	public static void setCellData(String xlfile,String xlsheet,int rownum,int colnum,String data) throws IOException
	{
		fi = new FileInputStream(xlfile);
		wb = new XSSFWorkbook(fi);
		ws = wb.getSheet(xlsheet);
		row = ws.getRow(rownum);
		cell = row.createCell(colnum);
		cell.setCellValue(data);
		fo = new FileOutputStream(xlfile);
		wb.write(fo);
		wb.close();
		fi.close();
		fo.close();
		
	}
	public static String triminvitationcode(String input) {
Pattern pattern = Pattern.compile("\\b[A-Z0-9]+-[A-Z0-9]+-[A-Z0-9]+\\b");
        
        // Create a matcher object
        Matcher matcher = pattern.matcher(input);
        
        // Find the matching string
        if (matcher.find()) {
            String extractedString = matcher.group();
            return extractedString;
        } else {
            System.out.println("No matching string found.");
        }
		return input;
	}
	
	public static String cleanString(String input) {
        // Step 1: Trim the string (if necessary)
        String trimmed = input.trim();

        // Step 2: Remove all non-alphanumeric characters
        String cleaned = trimmed.replaceAll("[^a-zA-Z0-9]", "");

        return cleaned;
	}
	
	public static boolean isElementPresent(WebElement locatorKey) {
		try {
			locatorKey.isDisplayed();
			return true;
		} catch (Exception e) {
			return false;
		}
	}
	
	public String read_datafrom_json() throws IOException {
		String jsonvalue=null;
		try {
			String currentDir = System.getProperty("user.dir");
			String filePath = currentDir + File.separator + "sample1.json";
			System.out.println(filePath);         

			String content = new String(Files.readAllBytes(Paths.get(filePath)));
			System.out.println(content); 
			                     
			JSONObject jsonObject = new JSONObject(content);
			jsonvalue = jsonObject.getString("fruit");
//			System.out.println(jsonvalue);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return jsonvalue;
		
	}
	
	
//	public static void scrollpage(WebElement element) {
//		JavascriptExecutor js = (JavascriptExecutor)
//				js.executeScript("arguments[0].scrollIntoView(true);",element);	
//  
//	}

	}



