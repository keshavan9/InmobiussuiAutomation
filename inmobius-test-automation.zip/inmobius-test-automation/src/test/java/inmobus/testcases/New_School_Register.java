package inmobus.testcases;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.qa.hubspot.listeners.TestAllureListeners;

import inmobius.POM.school_RegisterPOM;
import inmobius.POM.superAdmin_POMPage;
import inmobius.utilities.readConfig;
import inmobius.utilities.xutils;
@Listeners({ TestAllureListeners.class })
public class New_School_Register extends base_class {
	readConfig rcfg=new readConfig();
	public String AdminUSN = rcfg.getAdminUsername();
	public String AdminPWD = rcfg.getAdminPassword();
	public String schAdminUser= rcfg.schoolAdminUsername();
	public String schAdminPassword=rcfg.schoolAdminUserpwd();
	public String SchoolName=rcfg.getSchoolName();
      String result;
      String invitecode;
      String finalcode;
      WebElement NextPageLink;
      
//@Test
	 public void New_School_Registration() throws InterruptedException, AWTException {
		 superAdmin_POMPage al = new superAdmin_POMPage(driver);
		 
		 school_RegisterPOM srp=new school_RegisterPOM(driver);
	       	  al.clickon_school();
	       	JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,500)", "");
			Thread.sleep(2000);
		      al.clickon_schoolLogin();
				Select objSelect = new Select(al.selectAccountType());
		        objSelect.selectByIndex(2);
				al.enterUserName(AdminUSN);
				al.enterPassword(AdminPWD);
				al.clickOnLogin();
				Thread.sleep(5000);
				srp.invitation_codebutton();
				srp.mapnew_code_button_click();
				Thread.sleep(3000);
//				srp.enter_TenantID("Create tenent from ChatBOT-(107262)");
				srp.enter_TenantID("Inmobius school by infinity learn-(100680)");
				srp.map_click();
				Thread.sleep(4000);
				srp.enter_tenantName("inmobius school by infinity learn");
				WebElement unusedcodestatus = null;
				while (true) {
		            try {
		            	unusedcodestatus = driver.findElement(By.xpath("//td[text()=\" UNUSED \"]/parent::*"));
		            	System.out.println(unusedcodestatus);
		                break; 
		            } catch (Exception e) {
//		            	 WebElement NextPageLink = driver.findElement(By.xpath("//*[@id=\"studentTable_next\"]/a"));
		            	 WebElement NextPageLink = driver.findElement(By.xpath("//*[@id=\"studentTable_next\"]"));
		            	 Thread.sleep(3000);
		            	 js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
		            	 Actions act = new Actions(driver);
		            	 act.sendKeys(Keys.DOWN).perform();
		            	 WebDriverWait wait = new WebDriverWait(driver, 10);
		                 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(NextPageLink));
		                 driver.navigate().refresh();
		                 srp.enter_tenantName("inmobius school by infinity learn");
		                 js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
		                 element.click();
		            }
		        }
//				for(int i=0;i<=20;i++) {
//					Thread.sleep(2000);
//				 if(xutils.isElementPresent(driver.findElement(By.xpath("//td[text()=' UNUSED ']")))) {
//					 Thread.sleep(1000);
//				String invitationcode=driver.findElement(By.xpath("//td[text()=\" UNUSED \"]/parent::*")).getText();
//				System.out.println(invitationcode);
//				invitecode=xutils.triminvitationcode(invitationcode);
//				System.out.println(invitecode);
//					 break;
//				 }else {
//					 js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
//					 Actions act = new Actions(driver);
//	            	 act.sendKeys(Keys.DOWN).perform();
//					 NextPageLink.click();
//				 }
//				}
				Thread.sleep(2000);
				srp.logouttoggle();
				srp.logoutbutton();
				driver.get(baseUrl);
				srp.schoolbuttononhomepage();
				srp.school_firstName("Automation School");
//				Thread.sleep(4000);
//				srp.click_chatbot();
//				srp.close_chatbot();
				Random randomGenerator = new Random();  
				int randomInt = randomGenerator.nextInt(1000);   
				srp.email_ID("username"+ randomInt +"@gmail.com");
				srp.school_name("Automation school");
				Thread.sleep(1000);
//				finalcode=xutils.cleanString(invitecode);
				srp.enter_invitationcode(invitecode);
				long randomNumber = (long) (Math.random() * 9_000_000_000L) + 1_000_000_000L;
				System.out.println(randomNumber);
				String str = Long.toString(randomNumber);
				srp.enter_number(str);
				js.executeScript("window.scrollBy(0,450)", "");
				Thread.sleep(20000);
				srp.click_continuebutton();
				xutils xl=new xutils();
				String isd_code="+91";
				String phone=str;
			    String tenant_id="99999";
			    String product_id="100";
				Thread.sleep(2000);
				srp.enter_Opt(xl.generateOTP(isd_code, phone, tenant_id, product_id));
//				srp.enter_Opt("1111");
				Thread.sleep(4000);
				srp.click_continuebutton();
				Thread.sleep(2000);
				js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
				srp.start_now();
				srp.schooltype_dropdown();
				srp.select_schooltype();
				srp.schoolBoard("CBSE");
				srp.Enter_BranchName("Main");
				srp.enter_schoolAddress("School Address");
				js.executeScript("window.scrollBy(0,450)", "");
				Thread.sleep(2000);
				srp.click_country_dropdown();
				srp.select_india();
				srp.click_statedropdown();
				js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
				srp.selectstate();
				
				
				}
}