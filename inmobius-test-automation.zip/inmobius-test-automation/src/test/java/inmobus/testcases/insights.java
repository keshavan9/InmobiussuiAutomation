package inmobus.testcases;

import static org.testng.Assert.assertNotNull;

import java.io.IOException;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

//import com.aventstack.extentreports.Status;
import com.qa.hubspot.listeners.TestAllureListeners;
import com.qa.hubspot.listeners.TestListeners;

//import inmobius.utilities.ExtentReports1;
import inmobius.utilities.readConfig;
import inmobius.utilities.xutils;
@Listeners({ TestAllureListeners.class, TestListeners.class })
public class insights extends base_class {
	xutils xt=new xutils();
	readConfig rcfg=new readConfig();
	
	@Test
	public void live_insights() throws InterruptedException, IOException  {
		driver.get("https://insights.devinfinitylearn.in/");
		 WebElement textfield=driver.findElement(By.id("school_id"));
		 String rd =System.getProperty("user.dir") + rcfg.getxlsheetpath();
			String d = xutils.getCellData(rd, "InputData", 1, 1);
			try {
				textfield.sendKeys(d);
			} catch (NoSuchElementException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
//				ExtentReports1.test.log(Status.FAIL, textfield+e.getMessage());
			
			}catch(Exception e) {
				e.printStackTrace();
			}
		 driver.findElement(By.xpath("//button[text()=\"Get Data\"]")).click();
		 Thread.sleep(5000);
		String Stduentcount=driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div/div/div/div[1]")).getText();
		 System.out.println("Students count for the school ID 'SCH1001006805' is "+ Stduentcount);
		 
		  StringBuffer num = new StringBuffer();
		        for (int i=0; i<Stduentcount.length(); i++)  
		{  
		            if (Character.isDigit(Stduentcount.charAt(i)))  
		                num.append(Stduentcount.charAt(i));  
		           
		        }   	
			    int b = Integer.parseInt(num.toString());
              System.out.println(b);
				if (b==0) {
					Assert.fail();
				}
				
			}
		 }  
	       
	
	

